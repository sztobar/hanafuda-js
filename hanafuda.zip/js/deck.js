hanafuda.cards = function () {

	var cardsimg = new Image();
	cardsimg.src = '../img/cards.png';
	var cardback = new Image();
	cardback.src = '../img/back.png';
	
	function Card (month, type, imgx, imgy) {
		var month = month; // 1 - 12
		var type = type; // 1 - 4
		var imgx = ix; // 56
		var imgy = iy; // 90
		thix.x = 20;
		this.y = 177;
		this.width = 56;
		this.height = 90;
		this.vis = true;
		this.busy = false;
		this.draw = function () {
			if (this.vis) {
				ctx.drawImage(cardsimg, imgx, imgy, this.width, this.height, this.x, this.y, this.width, this.height);
			} else {
				ctx.drawImage(cardback, this.x, this.y, this.width, this.height);
			}
		};
		getBusy = function () {
				return busy;
		};
		match = function (card) {
				return (month === card.getMonth());
		};
		getMonth = function () {
				return month;
		};
		getType = function () {
				return type;
		};
		toogleBusy = function () {
				if (busy) {
						busy = false;
				} else {
						busy = true;
				}
		};
	};
	
	function Deck () {
		var cards = [];
		cards.push(new Card(1, 1, 0, 0));
		cards.push(new Card(1, 1, 56, 0));
		cards.push(new Card(1, 2, 112, 0));
		cards.push(new Card(1, 4, 168, 0));
		cards.push(new Card(2, 1, 0, 90));
		cards.push(new Card(2, 1, 56, 90));
		cards.push(new Card(2, 2, 112, 90));
		cards.push(new Card(2, 3, 168, 90));
		cards.push(new Card(3, 1, 0, 180));
		cards.push(new Card(3, 1, 56, 180));
		cards.push(new Card(3, 2, 112, 180));
		cards.push(new Card(3, 4, 168, 180));
		cards.push(new Card(4, 1, 0, 270));
		cards.push(new Card(4, 1, 56, 270));
		cards.push(new Card(4, 2, 112, 270));
		cards.push(new Card(4, 3, 168, 270));
		cards.push(new Card(5, 1, 0, 360));
		cards.push(new Card(5, 1, 56, 360));
		cards.push(new Card(5, 2, 112, 360));
		cards.push(new Card(5, 3, 168, 360));
		cards.push(new Card(6, 1, 0, 450));
		cards.push(new Card(6, 1, 56, 450));
		cards.push(new Card(6, 2, 112, 450));
		cards.push(new Card(6, 3, 168, 450));
		cards.push(new Card(7, 1, 224, 0));
		cards.push(new Card(7, 1, 280, 0));
		cards.push(new Card(7, 2, 336, 0));
		cards.push(new Card(7, 3, 392, 0));
		cards.push(new Card(8, 1, 224, 90));
		cards.push(new Card(8, 1, 280, 90));
		cards.push(new Card(8, 3, 336, 90));
		cards.push(new Card(8, 4, 392, 90));
		cards.push(new Card(9, 1, 224, 180));
		cards.push(new Card(9, 1, 280, 180));
		cards.push(new Card(9, 2, 336, 180));
		cards.push(new Card(9, 3, 392, 180));
		cards.push(new Card(10, 1, 224, 270));
		cards.push(new Card(10, 1, 280, 270));
		cards.push(new Card(10, 2, 336, 270));
		cards.push(new Card(10, 3, 392, 270));
		cards.push(new Card(11, 1, 224, 360));
		cards.push(new Card(11, 2, 280, 360));
		cards.push(new Card(11, 3, 336, 360));
		cards.push(new Card(11, 4, 392, 360));
		cards.push(new Card(12, 1, 224, 450));
		cards.push(new Card(12, 1, 280, 450));
		cards.push(new Card(12, 1, 336, 450));
		cards.push(new Card(12, 4, 392, 450));
		for (var j, x, i = cards.length; i; j = parseInt(Math.random() * i, 10), x = cards[--i], cards[i] = cards[j], cards[j] = x);
		this.x = 20;
		this.y = 177;
		this.width = 56;
		this.height = 90;
		this.freecard = undefined;
		this.draw = function () {
		    ctx.drawImage(cardback, this.x, this.y, this.width, this.height);
		    if (this.freecard !== undefined) {
		        this.freecard.draw();
		    }
		};
		this.stroke = function () {
		    ctx.strokeRect(this.x - 5, this.y - 5, this.width + 10, this.height + 10);
		},
        this.click = function (mx, my) {
            if (gamestate === 1) {
                card = cards.pop();
                table.add(card);
                gamestate = 1;
            }
            else if (gamestate === 3) {
                //card = cards.pop();
                this.freecard = cards.pop();
                this.freecard.vis = true;
                this.freecard.y += 5;
                gamestate = 4;
                draw();
                //this.freeslot.attach(card, this);
            }
        };
		this.pop = function () {
		    return cards.pop();
		};
		this.isClicked = function (mx, my) {
		    if (mx >= this.x && mx <= (this.x + this.width) &&
                            my >= this.y && my <= (this.y + this.height)) {
		        this.click(mx, my);
		    }
		};
	};

	return {
	    Card: Card(),
	    Deck: Deck()
	};
};
