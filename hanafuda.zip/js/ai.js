var hanafuda = hanafuda || {};
hanafuda.ai = function () {

};
