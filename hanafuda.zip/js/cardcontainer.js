﻿var hanafuda = hanafuda || {};
hanafuda.cardcontainer = function () {
	var nocard = hanafuda.deck.Card();
	nocard.vis = false;

    function CardContainer(x, y, v) {
        this.cardspos = [];
        this.cards = [];
        this.x = x;
        this.y = y;
        this.width = 0;
        this.height = 90;
        this.vis = v;
        this.action = function (i) {};
        this.draw = function () {
            for (var i = 0; i < this.cards.length; ++i) {
                if (this.cards[i]) {
                    this.cards[i].draw();
                }
            }
        };
        this.stroke = function (ctx) {
            ctx.strokeRect(this.x - 5, this.y - 5, this.width + 5, this.height + 10);
        };
        this.align = function () {
            for (var i = 0; i < this.cards.length; ++i) {
                if (this.cards[i] === undefined) {
                    for (var j = i; j <= this.cards.length - 1; ++j) {
                        this.cards[j] = this.cards[j + 1];
                        if (this.cards[j]) {
                            this.cards[j].x = this.cardspos[j].x;
                            this.cards[j].y = this.cardspos[j].y;
                        }
                    }
                }
            }
        };
        this.add = function (card) {
            for (var i = 0; i < this.cards.length; ++i) {
                if (this.cards[i] === nocard) {
					this.cards[i] = card;
					card.x = this.cardspos[i].x;
					card.y = this.cardspos[i].y;
					this.width += 61;
					console.log("Dodaję kartę na indeks - " + i + " o pozycji: " + this.cardspos[i].x + ", " + this.cardspos[i].y);
					break;
                }
            }
			/*
            card.vis = this.vis;
            var free_index = this.freeSlot();
            var slot = this.cardspos[free_index];
            var dx = (slot.x - card.x) / 20;
            var dy = (slot.y - card.y) / 20;
            delayfun(function () {
                card.x += dx;
                card.y += dy;
                draw();
                card.draw();
            }, 10, 20);
            this.cards[free_index] = card;
            this.width += 61;*/
        };
        this.freeSlot = function () {
            if (this.cards.length === 0) {
                return 0;
            }
            for (var i = 0; i < this.cards.length; ++i) {
                if (this.cards[i] === undefined) {
					this.cards[i] = nocard;
                    return i;
                }
            }
        };
        this.isClicked = function (mx, my) {
            if (mx >= this.x && mx <= (this.x + this.width) &&
				my >= this.y && my <= (this.y + this.height)) {
                this.click(mx, my);
            }
        };
        this.click = function (mx, my) {
            //console.log("kliknieto kontener");
            var i;
            for (i = 0; i < this.cards.length; ++i) {
                if (this.cards[i] && !this.cards[i].getBusy()) {
                    if (mx >= this.cards[i].x && mx <= (this.cards[i].x + this.cards[i].width) &&
						my >= this.cards[i].y && my <= (this.cards[i].y + this.cards[i].height)) {
                        //console.log("Kliknieto karte");
                        this.cards[i].draw();
                        this.action(i);
                        i = this.cards.length + 1;
                        break;
                    }
                }
            }
            if (i !== this.cards.length + 1) {
                this.action2(i, true); //Specjalna metoda dla table
            }
        };
        this.remove = function (i) {
            var cardtmp = this.cards[i];
            //cardtmp.vis = true;
            this.width -= 61;
            this.cards[i] = undefined;
            return cardtmp;
        };
    }

	function FreeSlot() {
		this.attach = function (card, table, tabi) {
            card.vis = true;
            this.tabi = tabi;
			this.table = table;
            table.cards[tabi].toogleBusy();
            //this.cardplacer = table.cardspos[tabi];
            this.x = table.cardspos[tabi].x + 5;
            this.y = table.cardspos[tabi].y + 5;
            var dx = (this.x - card.x) / 20;
            var dy = (this.y - card.y) / 20;
            /*delayfun(function () {
                card.x += dx;
                card.y += dy;
                draw();
                card.draw();
            }, 10, 20);*/
            this.card = card;
        };
        this.remove = function () {
            var cardtmp = this.card;
            this.card = undefined;
            return cardtmp;
        };
        this.removeplacer = function () {
            this.table.cards[this.tabi].toogleBusy();
            return this.table.remove(this.tabi);
        };
        this.ready = function () {
            if (this.table.cards[this.tabi] && this.card) {
                return true;
            }
            else {
                return false;
            }
        };
        this.draw = function () {
            if (this.cardplacer !== undefined) {
                this.cardplacer.draw();
            }
            if (this.card !== undefined) {
                this.card.draw();
            }
        };
    }

	function DealtCardContainer(x, y) {
        this.x = x;
        this.y = y;
        this.width = 56;
        this.height = 90;
        this.cards = [];
        this.buff = 0;
        this.align = function () {
            for (var i = 0; i < this.cards.length; ++i) {
                this.cards[i].x = this.x + (i * 10);
            }
        };
        this.add = function (card) {
            var dx = (this.x - card.x) / 20;
            //console.log("x - card.x/20: " + this.x + " - " + card.x + " = " + ((this.x - card.x) / 20));
            var dy = (this.y - card.y) / 20;
            this.align();
            /*delayfun(function () {
                card.x += dx;
                card.y += dy;
                draw();
                card.draw();
            }, 10, 20);*/
            this.cards.push(card);
            this.width += 10;
        };
        this.draw = function () {
            this.align();
            for (var i = 0; i < this.cards.length; ++i) {
                this.cards[i].draw();
            }
        };
    }

	/*
	 * Klasa zagranych zwyklych
	 */
    function Dealt(x, y, player) {
        this.set = [];
        this.x = x;
        this.y = y;
        this.mypoints = 0;
        this.player = player;
        this.set.push(new DealtCardContainer(x - 56, y));
        this.set.push(new DealtCardContainer(x - 56, y));
        this.set.push(new DealtCardContainer(x - 56, y));
        this.set.push(new DealtCardContainer(x - 56, y));
        this.align = function () {
            var j = 0;
            for (var i = 0; i < 4; ++i) {
                if (this.set[i].cards.length) {
                    this.set[i].x = this.x - this.set[i].width - j;
                    j += this.set[i].width;// + 5;
                }
            }
        };
        this.add = function (card) {
            var i = card.getType() - 1;
            this.set[i].add(card);
        };
        this.draw = function (ctx, Text) {
            this.align();
            Text.set();
            for (var i = 0; i < 4; ++i) {
                if (this.set[i].cards.length) {
                    ctx.fillText(this.set[i].cards.length, this.set[i].x, this.set[i].y - 15);
                }
                this.set[i].draw();
            }
        };
        this.check = function () {
            var tmp = 0, points = 0, sets = [];
            if (this.set[3].cards.length >= 3) {
                var drunkmonk = false;
                for (var i = 0; i < this.set[3].cards.length; ++i) {
                    if (this.set[3].cards[i].getMonth === 11) {
                        drunkmonk = true;
                    }
                }
                if (this.set[3].cards.length === 5) {
                    points += 10;
                    sets.push("Goko = 10");
                } else if (this.set[3].cards.length === 4) {
                    tmp = 8 - (drunkmonk ? 1 : 0);
                    points += tmp;
                    sets.push("Shiko = " + tmp);
                } else if (this.set[3].cards.length === 3 && !drunkmonk) {
                    points += 5;
                    sets.push("Sanko = 5");
                }
            }
            if (this.set[2].cards.length >= 3) {
                if (this.checkInSet(this.set[2].cards, Checkers.inoshikacho) === 3) {
                    points += 3;
                    sets.push("inoshikacho = 3");
                }
                if (this.set[2].cards.length >= 5) {
                    tmp = 1 + (this.set[2].cards.length - 5);
                    points += tmp;
                    sets.push("tane = " + tmp);
                }
            }
            if (this.set[1].cards.length >= 3) {
                if (this.checkInSet(this.set[1].cards, Checkers.akatan) === 3) {
                    points += 3;
                    sets.push("akatan = 3");
                }
                if (this.checkInSet(this.set[1].cards, Checkers.aotan) === 3) {
                    points += 3;
                    sets.push("aotan = 3");
                }
                if (this.set[1].cards.length >= 5) {
                    tmp = 1 + (this.set[1].cards.length - 5);
                    points += tmp;
                    sets.push("tan = " + tmp);
                }
            }
            if (this.set[0].cards.length >= 10) {
                tmp = 1 + (this.set[0].cards.length - 10);
                points += tmp;
                sets.push("kase = " + tmp);
            }
            if (points > this.mypoints) {
                this.mypoints = points;
                //gamestate = this.player;
                //Win(this, sets);
                console.log("Nowy wynik! " + points);
                console.log(sets);
            }
        };
		this.checkInSet = function (cards, fun) {
			var tmp = 0;
			for (var i = 0; i < cards.length; ++i) {
				if (fun(cards[i])) {
					++tmp;
				}
			}
			return tmp;
		};
    }

	var Checkers = {
        special: function (card) {
            return (card.getType() === 4);
        },
        inoshikacho: function (card) {
            return ((card.getType() === 3 && card.getMonth() === 6) || (card.getType() === 3 && card.getMonth() === 7) || (card.getType() === 3 && card.getMonth() === 10));
        },
        akatan: function (card) {
            return ((card.getType() === 2 && card.getMonth() === 6) || (card.getType() === 2 && card.getMonth() === 9) || (card.getType() === 2 && card.getMonth() === 10));
        },
        aotan: function (card) {
            return ((card.getType() === 2 && card.getMonth() === 1) || (card.getType() === 2 && card.getMonth() === 2) || (card.getType() === 2 && card.getMonth() === 3));
        },
        tane: function (card) {
            return (card.getType() === 3);
        },
        tan: function (card) {
            return (card.getType() === 2);
        },
        kasu: function (card) {
            return (card.getType() === 1);
        }
    };


	return {
		CardContainer: CardContainer,
		FreeSlot: FreeSlot
	};
};
