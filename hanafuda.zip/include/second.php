<?php
echo <<<SECOND
        </section>
			<footer>
				Bartosz Szewczyk 2013 &copy; Projekt na Techniki Internetowe
    		</footer>
		</section>
	</section>
</body>
</html>
SECOND;
?>
